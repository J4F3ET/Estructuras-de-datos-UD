#include<string.h>
#include<stdio.h>
#include "Asignatura.h"

Asignatura::Asignatura()
{
	codigo=0;
	estado=0;
	creditos=0;
	strcpy(descripcion," ");
	strcpy(nombre," ");
	//printf("Constuyendo sin parametros\n");
}

Asignatura::Asignatura(int cod, char nom[25])
{
	codigo=cod;
	estado=0;
	creditos=0;
	strcpy(descripcion," ");
	strcpy(nombre,nom);
	//printf("Constuyendo con 2 parametros\n");
}

Asignatura::Asignatura(int cod, char nom[25], int cre, int est)
{
	codigo=cod;
	estado=est;
	creditos=cre;
	strcpy(descripcion," ");
	strcpy(nombre,nom);
	//printf("Constuyendo con 4 parametros\n");
}


Asignatura::~Asignatura()
{
}

void Asignatura::setCreditos(int cred)
{
	creditos=cred;
}

void Asignatura::setCodigo(int cod)
{
	codigo=cod;
}

void Asignatura::setEstado(int est)
{
	estado=est;
}

void Asignatura::setDescripcion(char des[50])
{
	strcpy(descripcion,des);
}

void Asignatura::setNombre(char nom[25])
{
	strcpy(nombre,nom);
}

int Asignatura::getCreditos()
{
	return(creditos);
}

int Asignatura::getCodigo()
{
	return(codigo);
}

int Asignatura::getEstado()
{
	return(estado);
}

char *Asignatura::getNombre()
{
	return(nombre);
}

char *Asignatura::getDescripcion()
{
	return(descripcion);
}

