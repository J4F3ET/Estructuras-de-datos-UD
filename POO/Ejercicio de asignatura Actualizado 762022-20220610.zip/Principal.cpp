#include <iostream>
#include<string.h>
#include"Asignatura.h"

menu()
{
	printf("\nOPCIONES\n");
	printf("1 Cambiar Nombre\n");
	printf("2 Cambiar C�digo\n");
	printf("3 Cambiar Estado\n");
	printf("4 Cambiar # Creditos\n");
	printf("5 Cambiar Descripcion\n");
	printf("6 Mostrar datos Asignatura\n");
	printf("7 Buscar asignatura\n");
	//printf("\n");
	//printf("\n");
}

main() 
{
	int op,ent,n,i;
	bool sw;
	int pos;
	char auxc[25];
	//printf("Codigo asignatura por defecto: ");
	//scanf("%d",&ent);
	//Asignatura obj1,obj2(ent,"Ingles"),obj(ent,"Frances",3,1);
	Asignatura obj[5];
	n=0;
	pos=0;
	sw=0;
	do
	{
		menu();
		scanf("%d",&op);
		switch(op)
		{
			case 1:	{
						printf("\nNombre de la Asignatura: ");
						fflush(stdin);
						gets(auxc);
						printf("Objeto [1..5]: ");
						scanf("%d",&n);
						obj[n-1].setNombre(auxc);
						break;
					}
			case 2:	{
						printf("Codigo de la Asignatura: ");
						scanf("%d",&ent);
						printf("Objeto [1..5]: ");
						scanf("%d",&n);
						obj[n-1].setCodigo(ent);
						break;
					}
			case 3:	{
						printf("Estado de la Asignatura [1 Activa, 0 Inactiva]: ");
						scanf("%d",&ent);
						printf("Objeto [1..5]: ");
						scanf("%d",&n);						
						obj[n-1].setEstado(ent);
						break;
					}
			case 4:	{
						printf("Cr�ditos de la Asignatura: ");
						scanf("%d",&ent);
						printf("Objeto [1..5]: ");
						scanf("%d",&n);
						obj[n-1].setCreditos(ent);
						break;
					}
			case 5:	{
						printf("\nDescripcion de la Asignatura: ");
						fflush(stdin);
						gets(auxc);
						printf("Objeto [1..5]: ");
						scanf("%d",&n);
						obj[n-1].setDescripcion(auxc);				
						break;
					}
			case 6:	{
						printf("Datos de la Asignatura\n");
						printf("Nombre \t\tCodigo \t\t Estado\t\t Creditos \t\t Descripcion\n");
						for(i=0;i<5;i++)
						{
							printf(obj[i].getNombre());
							printf("\t\t%d",obj[i].getCodigo());
							if(obj[i].getEstado()==1)
								printf("\t\tActiva");
							else
								printf("\t\tInactiva");
							printf("\t\t%d",obj[i].getCreditos());
							printf("\t\t%s\n",obj[i].getDescripcion());
						}
						break;
					}
			case 7: {
						printf("Codigo de asignatura a buscar: ");
						scanf("%d",&ent);
						for(i=0;i<5;i++)
						{
							if(ent==obj[i].getCodigo())
							{
								pos=i;
								sw=1;
							}
						}
						if(sw)
						{
							printf("Nombre \t\tCodigo \t\t Estado\t\t Creditos \t\t Descripcion\n");
							printf(obj[pos].getNombre());
							printf("\t\t%d",obj[pos].getCodigo());
							if(obj[pos].getEstado()==1)
								printf("\t\tActiva");
							else
								printf("\t\tInactiva");
							printf("\t\t%d",obj[pos].getCreditos());
							printf("\t\t%s\n",obj[pos].getDescripcion());
						}
						else
							printf("Asingatura no Existe\n");
			
				/*
						printf("Codigo de asignatura a buscar: ");
						scanf("%d",&ent);
						printf("Nombre:\t\t%s\n",obj.getNombre());
						if(obj.getEstado()==1)
							printf("Estado: \tActiva\n");
						else
							printf("Estado: \tInactiva\n");
				*/
				/*		printf("Nombre de asignatura a buscar: ");
						fflush(stdin);
						gets(auxc);
						//ent=strcmp(obj.getNombre(),auxc);
						if(ent==0)
						{          							
						//	printf("Codigo:\t%d\n",obj.getCodigo());
						//	if(obj.getEstado()==1)
								printf("Estado: \tActiva\n");
						//	else
								printf("Estado: \tInactiva\n");
						}
						else
							printf("No existe");
				*/
						break;
					}
			default: break;
		}
	}while((op>0)&&(op<8));
}
