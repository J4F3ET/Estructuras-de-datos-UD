#ifndef ASIGNATURA_H
#define ASIGNATURA_H

class Asignatura
{
	private:
		int creditos,estado,codigo;
		char descripcion[50],nombre[25];
	public:
		Asignatura();
		Asignatura(int cod, char nom[25]);
		Asignatura(int cod, char nom[25], int cre, int est);
		~Asignatura();
		void setCreditos(int cred);
		void setCodigo(int cod);
		void setEstado(int est);
		void setDescripcion(char des[50]);
		void setNombre(char nom[25]);
		int getCreditos();
		int getCodigo();
		int getEstado();
		char *getNombre();
		char *getDescripcion();
	protected:
};

#endif
