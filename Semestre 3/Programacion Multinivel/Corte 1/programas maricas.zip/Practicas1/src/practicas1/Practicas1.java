package practicas1;
import ControladorPractica.ControladorDivisor;
public class Practicas1 {
    public static void main(String[] args) {
        ControladorDivisor objControlador = new ControladorDivisor();
    }
}
