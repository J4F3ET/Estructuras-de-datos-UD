package listadecompras;
import Control.ControladorComboArrayList;
public class ListaDeCompras {
    public static void main(String[] args) {
        ControladorComboArrayList ObjControlador = new ControladorComboArrayList();
    }
    
}
