
package estructurascontrol;

import Controlador.ControladorMayor;


public class EstructurasControl {
    
    public static void main(String[] args) {
           ControladorMayor objControaldor= new ControladorMayor();
    }
    
}
