/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package funcionescorregido;

import Controlador.ControladorA;

/**
 *
 * @author WBES_
 */
public class FuncionesCorregido {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       ControladorA objControlador = new ControladorA();
    }
    
}
