package estructurasrepetitivas;

import Controlador.Controlador;

public class EstructurasRepetitivas {
    public static void main(String[] args) {
        Controlador objControlador = new Controlador();
    }
    
}
