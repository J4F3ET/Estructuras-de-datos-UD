package arreglo;
import Controlador.ControladorArreglo;

public class Arreglo {
    public static void main(String[] args) {
        ControladorArreglo objControlador = new ControladorArreglo();
    }
    
}
