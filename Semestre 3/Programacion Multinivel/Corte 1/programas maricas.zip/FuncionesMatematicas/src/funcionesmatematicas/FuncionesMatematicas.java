package funcionesmatematicas;
public class FuncionesMatematicas {
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
