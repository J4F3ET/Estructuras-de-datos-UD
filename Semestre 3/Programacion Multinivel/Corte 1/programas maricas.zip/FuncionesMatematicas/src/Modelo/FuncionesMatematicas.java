package Modelo;
public class FuncionesMatematicas {
    String cadena = "";
    public String funcionesmatematicas(){
        cadena+="Alagunos metodos predefinidos por la clase MATH \n\n";
        cadena+="Valor absoluto de -250:"+Math.abs(-250)+"\n";
        cadena+="A"+"\n";
        cadena+="A"+"\n";
        cadena+="A"+"\n";
        cadena+="A"+"\n";
        cadena+=+"\n";
        cadena+=+"\n";
        cadena+=+"\n";
        cadena+=+"\n";
        cadena+=+"\n";
        cadena+=+"\n";
        
        
        return cadena;
    }
}
