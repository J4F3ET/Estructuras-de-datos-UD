package javaapplication3;

import Controlador.Controlador;

public class JavaApplication3 {
    public static void main(String[] args) {
        Controlador objControladore = new Controlador();
    }
    
}
