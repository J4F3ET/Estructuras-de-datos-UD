package Modelo;
public class Modelo {
    private String texto;
    public String getTexto() {
        return texto;
    }
    public void setTexto(String texto) {
        this.texto = texto;
    }
    public void parrafo(){
        System.out.println("Modelo.Modelo.parrafo()");
    }
}
