package practica2;

import Contralor.Controlador;

public class Practica2 {
    public static void main(String[] args) {
        Controlador objControlador= new Controlador();
    }
    
}
