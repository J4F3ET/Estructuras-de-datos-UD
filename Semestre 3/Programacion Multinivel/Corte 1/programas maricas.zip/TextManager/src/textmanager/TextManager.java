package textmanager;

import ControladorTexto.ControladorTexto;

public class TextManager {
    public static void main(String[] args) {
        ControladorTexto objTexto = new ControladorTexto();
    }
    
}
