package colores;

import ControladorComboBoxList.ControladorComboBoxList;

public class Colores {
    public static void main(String[] args) {
        ControladorComboBoxList objControlador = new ControladorComboBoxList();
    }
    
}
