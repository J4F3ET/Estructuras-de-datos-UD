package estructurasrepetitiaswhile;
public class EstructurasRepetitiasWhile {
    public static void main(String[] args) {
    }
    
}
