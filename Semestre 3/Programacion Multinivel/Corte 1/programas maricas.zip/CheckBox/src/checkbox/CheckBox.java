/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package checkbox;

import Controlador.ControladorCheckBox;

/**
 *
 * @author WBES_
 */
public class CheckBox {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ControladorCheckBox objControl = new ControladorCheckBox();
    }
    
}
